#ifndef INC_ERA_ESP32_SSL_HPP_
#define INC_ERA_ESP32_SSL_HPP_

#define ERA_MODBUS
#define ERA_ZIGBEE

#include <ERaSimpleEsp32SSL.hpp>

#endif /* INC_ERA_ESP32_SSL_HPP_ */
