#ifndef INC_ERA_LOGICROM_SSL_HPP_
#define INC_ERA_LOGICROM_SSL_HPP_

#define ERA_MODBUS

#include <ERaSimpleLogicromSSL.hpp>

#endif /* INC_ERA_LOGICROM_SSL_HPP_ */
