#ifndef INC_ERA_ZIGBEE_SIMPLE_HPP_
#define INC_ERA_ZIGBEE_SIMPLE_HPP_

#if defined(ERA_ZIGBEE)
    #include <Zigbee/ERaZigbee.hpp>
#endif

#endif /* INC_ERA_ZIGBEE_SIMPLE_HPP_ */
