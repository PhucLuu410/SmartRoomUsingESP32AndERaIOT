#ifndef INC_DEFINE_MANUFACTURERS_ZIGBEE_HPP_
#define INC_DEFINE_MANUFACTURERS_ZIGBEE_HPP_

namespace ZigbeeNamespace {

    enum ManufacturerCodesT {
        MANUF_CODE_NONE = 0x0000
    };

} /* namespace ZigbeeNamespace */

#endif /* INC_DEFINE_MANUFACTURERS_ZIGBEE_HPP_ */
